## ---- echo = FALSE, message = FALSE--------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup---------------------------------------------------------------
library(binomial)
library(ggplot2)

## ------------------------------------------------------------------------
bin_choose(10, 3)

## ------------------------------------------------------------------------
bin_probability(3, 10, 0.5)

## ------------------------------------------------------------------------
bin_distribution(trials = 10, prob = 0.5)

## ---- fig.show='hold'----------------------------------------------------
bindis1 <- bin_distribution(10, 0.5)
plot(bindis1)

## ------------------------------------------------------------------------
bin_cumulative(trials = 10, prob = 0.5)

## ---- fig.show='hold'----------------------------------------------------
bincum1 <- bin_cumulative(10, 0.5)
plot(bincum1)

## ------------------------------------------------------------------------
bin_variable(trials = 10, prob = 0.5)

## ------------------------------------------------------------------------
bin_var <- bin_variable(10, 0.5)
summary(bin_var)

## ------------------------------------------------------------------------
#mean
bin_mean(trials = 10, prob = 0.5)

#variance
bin_variance(trials = 10, prob = 0.5)

#mode
bin_mode(trials = 10, prob = 0.5)

#skewness
bin_skewness(trials = 10, prob = 0.5)

#kurtosis
bin_kurtosis(trials = 10, prob = 0.5)

